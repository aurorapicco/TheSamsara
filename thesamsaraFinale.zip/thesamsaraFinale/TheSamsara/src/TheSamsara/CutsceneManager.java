package TheSamsara;

import java.awt.Graphics2D;

public class CutsceneManager {
	PannelloMappaGioco gp;
	Graphics2D g2;
	public int sceneNum;
	public int scenePhase;
	
	public final int Na = 0;
	
	public CutsceneManager(PannelloMappaGioco gp) {
		this.gp = gp;
	}
	
	public void draw (Graphics2D g2) {
		this.g2 = g2;
	}
	
	
	
	
	}