package TheSamsara;

import java.awt.BorderLayout;

import java.awt.Graphics2D;
import java.awt.image.BandCombineOp;

import javax.swing.JLabel;
import javax.swing.JPanel;

import entity.Athena;
import entity.Cavaliere;
import entity.Emmet;
import entity.Entity;
import entity.Gigante;
import entity.LordSwain;
import entity.PadreViscur;
import entity.Player;
import entity.npc_Ilde;
import tile.TileManager;
import entity.Player;


public class Scena {
	public PannelloMappaGioco gp;
	Cavaliere cav1,cav2,cav3,cav4,cav5;
	npc_Ilde Ilde;
	Athena athena;
	LordSwain sw;
	TileManager tm;
	Protagonista pro;
	Nemico gigante1,gigante2,boss;
	Emmet emmet;
	Boolean combattimento = false;
	Gigante g1 ,g2 ,g3;
	Dialoghi dcomb;
	PadreViscur pv ;
	public Dialoghi a;
	Player mc;
	public int vinto = 4;
	Graphics2D gr;
	private int i ;
	
	public Scena(PannelloMappaGioco gp ,TileManager tm , Cavaliere cav1 , Athena athena , npc_Ilde Ilde ,LordSwain sw ,PadreViscur pv,Gigante g1 ,Gigante g2 ,Gigante g3,Cavaliere cav2 ,Cavaliere cav3,Cavaliere cav4,Cavaliere cav5,Protagonista pro , Nemico gigante1 ,Nemico gigante2 , Nemico boss ,Dialoghi dcomb,Emmet emmet, Dialoghi a) {
		this.gp = gp;
		this.mc = mc;
		this.cav1 = cav1;
		this.cav2 = cav2;
		this.cav3 = cav3;
		this.cav4 = cav4;
		this.cav5 = cav5;
		this.gigante1=gigante1;
		this.gigante2=gigante2;
		this.emmet = emmet;
		this.boss = boss;
		this.athena = athena;
		this.Ilde = Ilde;
		this.pro = pro;
		this.g1 = g1;
		this.g2 = g2;
		this.g3 = g3;
		this.sw = sw;
		this.tm = tm;
		this.pv = pv;
		this.dcomb = dcomb;
		this.a = a;
		this.i = 0;
	}
	//qua andranno le scene

	public int scene(Player mc,int i)  {

		switch(i) {

		case 0: 
			mc.setPosition(100, 100);
			athena.setDefaultValues();
			emmet.setDefaultValues();
			break;
		case 1: 
			Ilde.setPosition(150, 100);
			break;
		case 2: 
			Ilde.setDefaultValues();
			sw.setPosition(150, 100);
			pro.aumentaResistenza(5);
			Arma spadadiLegno = new Arma("Spada Di Legno", 5, true);
			pro.setSpada(spadadiLegno);
			Colpo stoccata = new Colpo("Stoccata", 1, 1, 'E');
			pro.aggiungiColpo(stoccata);
			break;
		case 3: 
			sw.setDefaultValues();
			pv.setPosition(150,350);
			mc.setPosition(250, 350);
			Item pozione = new Cura("Pozione rigenerante", 10);
			pro.aggiungiInventario(pozione);
			break;

		case 4:
			mc.setPosition(100, 300);
			pv.setDefaultValues();
			g1.setPosition(300,375);
			g2.setPosition(345,375);
			g3.setPosition(325,400);
			break;
		case 5:
			mc.setPosition(100, 375);
			g1.setDefaultValues();
			g2.setDefaultValues();
			g3.setDefaultValues();
			break;

		case 6:
			mc.setPosition(100, 400);
			athena.setPosition(200, 400);
			cav1.setPosition(250, 400);
			cav2.setPosition(300, 380);
			cav3.setPosition(300, 420);
			cav4.setPosition(345, 400);
			cav5.setPosition(380, 400);
			break;
		case 7: 
			mc.setPosition(200, 400);
			athena.setPosition(400, 400);
			pro.aumentaForza(10);
			Colpo doppioColpo = new Colpo("Doppio Colpo", 3, 2, 'Q');
			pro.aggiungiColpo(doppioColpo);
			cav1.setDefaultValues();
			cav2.setDefaultValues();
			cav3.setDefaultValues();
			cav4.setDefaultValues();
			cav5.setDefaultValues();
			break;
		case 8:
			athena.setDefaultValues();
			mc.setPosition(400, 425);
			g1.setPosition(200,400);
			g2.setPosition(200,435);
			break;
		case 9:
			boolean continua = false;
			mc.setPosition(400, 400);
			g1.setPosition(400,350);
			g2.setDefaultValues();
			int cond;
			try {
				cond = combattimento(mc ,g1 , pro , gigante1 );
				if(cond == 1)  {
					g1.setDefaultValues();
					g2.setPosition(400,350);
					continua = true;
					
				}
				else if( cond == 2){
					return 2;
				}
				else
				{
					
					}
				
				if(continua == true) {
					cond = combattimento(mc ,g2 , pro , gigante2);
					if(cond == 1) {
						return 1;
					}
				}
				
				//combattimento(mc ,g1 , pro , gigante1);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		case 10: 
			g2.setDefaultValues();
			mc.setPosition(400, 400);
			athena.setPosition(450, 400);
			break;
			
		case 11: 
			
			try {
				emmet.setPosition(350, 400);
				athena.setDefaultValues();
				int cond1 = combattimento(mc ,g1 , pro , boss );
				if(cond1 == 1) {
					return cond1;
				}
				else {
					return 2;
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;

		}
		return 15;
		
	}
	

	public  int combattimento(Player mc , Gigante g1, Protagonista p, Nemico n) throws InterruptedException  
	{
		int vinto = 2;
			
			while(p.isVivo() == true && n.isVivo() ==true) {
				int turno = 0;
				Thread.sleep(1000);
					System.out.println("TUA VITA: " + p.getVita());
					System.out.println("VITA NEMICO: " + n.getVita());
					System.out.println("Cosa vuoi fare? [E] Stoccata(ogni turno),\n [Q] Doppio colpo(ogni 3 turni), [Z] Cura");

					boolean error;
					char scelta;

					do
					{
						error = false;
						scelta = Leggi.unChar();
						if((scelta == 'Q' || scelta == 'q') && turno %  p.colpi[1].getTurno() != 0)
						{
							System.out.println("Errore! Controlla il turno...");
							error = true;
						}
						else if(scelta == 'Z' && p.getNumCure() <= 0)
						{
							System.out.println("Errore! Controlla quante cure possiedi...");
							error = true;
						}
					}
					while(error == true);

					if(scelta == 'E' || scelta == 'Q'|| scelta == 'e' || scelta == 'q')
					{
						int ris;

						if(scelta == 'E' || scelta == 'e')
							ris = 0;
						else
							ris = 1;

						n.prendiDanno((p.getSpada().getDanno() * p.colpi[ris].getDmgBonus()));
						//System.out.println("Hai inflitto " + (p.getSpada().getDanno() * p.colpi[ris].getDmgBonus()) + " danni");
					}
					else
					{
						for(int i = 0; i < p.getInventario().length; i++)
						{
							if(p.getInventario()[i] instanceof Cura)
							{
								p.cura(((Cura)p.getInventario()[i]).getCura());
								p.rimuoviInventario(i);
							}
						}
					}

					p.prendiDanno(n.getDanno() - p.getResistenza());

					
					
					turno++;
			}
			if(p.isVivo() == false) {
				System.out.println("HO Fallito ");
				vinto = 2;
				}
				else if(n.isVivo() == false){
					vinto = 1;
				}
			
				return vinto;
			
		
 }
	 
}

