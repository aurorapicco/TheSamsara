package entity;


import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import TheSamsara.Arma;
import TheSamsara.Colpo;
import TheSamsara.InputTastiera;
import TheSamsara.Nemico;
import TheSamsara.PannelloMappaGioco;
import TheSamsara.Protagonista;
import TheSamsara.Scena;
import tile.TileManager;

public class Player extends Entity {
	PannelloMappaGioco gp;
	InputTastiera keyH;
	TileManager tm;
	Scena scena;
	String nome;
	public Protagonista p;
	public Nemico n;
	public Nemico n2;
	public Nemico boss;
	
	Boolean combattimento;
	int z = 0;
	//protected Item[] inventario;
	int pos = 0;
	public int i;
	public int i2;
	public final int WT = 1000; //tempo di attesa

	public Player(PannelloMappaGioco gp, InputTastiera keyH,TileManager tm ,Scena scena ,Protagonista p , Nemico n , Nemico n2 , Nemico boss) {
		//super(nome ,vita);
		this.gp = gp;
		this.keyH = keyH;
		this.tm = tm;
		this.n = n;
		this.n2 = n2;
		this.boss = boss;
		this.p = p;
		this.scena = scena;
		combattimento = false;
		// this.inventario = new Item[10]; // Inizializza l'inventario con 10 slot
		
		

		setDefaultValues();
		getPlayerImage();
		setDialogo();
	}
	

	public void setDefaultValues() {
		x = 100;
		y = 100;
		speed = 4;
		direction = "down";
		i  = 0;
		//scena.scene(this,0);
	}

	public void setPosition(int x , int y) {
		this.x = x;
		this.y = y;
	}

	public void getPlayerImage() {

		try {
			left = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McFermoSx.png"));
			right = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McFermoDx.png"));
			attackLeft = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McCombattimentoSx.png"));
			attackRight = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McCombattimentoDx.png"));

			/*left = ImageIO.read(getClass().getResourceAsStream("/player/boy_down1.png"));
			right = ImageIO.read(getClass().getResourceAsStream("/player/boy_up21.png"));
			attackLeft = ImageIO.read(getClass().getResourceAsStream("/player/boy_left1.png"));
			attackRight = ImageIO.read(getClass().getResourceAsStream("/player/boy_right1.png"));
			 */
		} catch(IOException e) {
			e.printStackTrace();
		}

	}

	public void setDialogo() {
		//qua mettiamo tutti i dialoghi
		
		
		dialogo[0] = "Il portale si chiude dietro di me.";
		dialogo[1] = "Mc: Sono a casa?";
		dialogo[2] = "Mc: No ,questo posto non è casa mia";
		dialogo[3] = "Mc: Devo tornare a casa, dai miei fratelli.";
		dialogo[4] = "Un fulmine squarcia il cielo che fino a pochi \nattimi prima era sereno.";
		dialogo[5] = "La luce si fa sempre più vicina a me.\r\n";
		dialogo[6] = "E dopo una scarica sul corpo, buio totale.";
		//RISVEGLIO
		dialogo[7] = "Apro piano gli occhi";
		dialogo[8] = "???: Finalmente ti sei svegliato!";
		dialogo[9] = "Mc : Dove sono? Chi sei tu?";
		dialogo[10] = "???: Mi chiamo Ilde, sono una contadina, \n ti ho trovato a terra svenuto e ho deciso di portarti a casa mia.";
		dialogo[11] = "Mc: Ti ringrazio, Ilde.";
		dialogo[12] = "Ilde: Non sei di queste parti, vero? Qua tutti conoscono tutti, \ne la tua faccia \nnon credo di averla mai vista nei miei centosessant'anni di vita.";
		dialogo[13] = "-B: Cavolo! Li porta bene :O";
		dialogo[14] = "Mc: No, mi sono ritrovato qui per errore. \nSapresti dirmi dove mi trovo?";
		dialogo[15] = "Ilde: Benvenuto nel Regno di Mirvlar, dove il tempo è duraturo.";
		dialogo[16] = "Mc: Cosa vuol dire?";
		dialogo[17] = "Mc: Ilde mi ignora, sembra che non abbia sentito.";
		dialogo[18] = "Ilde: Dovresti raggiungere la città, \nperò non è molto vicina e la strada è piena di pericoli.";
		dialogo[19] = "Ilde: Oh! Dovrebbe essere arrivato!";
		dialogo[20] = "Mc: Chi?!";
		dialogo[21] = "Sta per dire qualcosa di ironico, \nma si ferma in tempo.";
		dialogo[22] = "-A: Ci è mancato poco";
		dialogo[23] = "* Un secondo per respirare* \n:) oppure di più";
		dialogo[24] = "Ilde: Mio marito, l'emerito cavaliere Lord Swain. \nTi insegnerà qualche tecnica di combattimento.";
		//ESCO DALLA CASA
		dialogo[25] = "Esco dalla casa e incontro un vecchietto.";
		dialogo[26] = "Buongiorno, lei è Lord Swain?";
		dialogo[27] = "Swain: Sono io, vieni caro, \nti insegnerò un trucchetto per sopravvivvere qui.";
		dialogo[28] = "Swain: Ora sei pronto. Segui il sentiero,\n ti porterà in città, \nbuon viaggio. Che i Tre ti proteggano!";
		//villaggio
		dialogo[29] = "Proseguo verso la strada principale.";
		dialogo[30] = "Arrivo a un villaggio molto rustico.";
		dialogo[31] = "Un prete mi sta fissando, che inquietante.";
		dialogo[32] =" ???: Salve straniero, dove sei diretto?";
		dialogo[33] = "Alla città.";
		dialogo[34] = "Padre Viscur: Io sono Padre Viscur,\n lieto di conoscerti.";
		dialogo[35] = "Piacere mio, la città è da quella parte?";
		dialogo[36] = "Padre Viscur: Esattamente.";
		dialogo[37] = "Allora ti ringrazio, arrivederci.";
		dialogo[38] = "Padre Viscur: Aspetta!\n La strada è molto pericolosa,\n voglio farti un regalo.";
		dialogo[39] = "Mi porge 5 pozioni curative.";
		dialogo[40] = "Padre Viscur: Queste le produco personalmente.\n Ti cureranno di 10 punti vita.";
		dialogo[41] = "Allora grazie e arrivederci";
		dialogo[42] = "Non ti hanno insegnato che non\n si accettano regali dagli sconosciuti? -G";
		dialogo[43] = "Padre Viscur: Buon viaggio, a presto.";
		//fuori il villaggio
		dialogo [44] = "Mi incammino fuori dal villaggio.";
		dialogo [45] = "Il suolo inizia a tremare.";
		dialogo [46] = "Che succede?\nC'è un terremoto?";
		dialogo [47] = "Un gruppo di giganti, alti circa 5 metri,\n mi passa davanti sparendo nella foresta.";
		dialogo [48] = "Erano parecchio di fretta.";
		dialogo [49] = "Una donna urla alle mie \nspalle: \"Aiuto! I nemici! I giganti ci distruggeranno!";
		dialogo [50] = "Sono loro che devo sconfiggere,\n i miei nemici.";
		//arrivo città
		dialogo [51] = "Arrivo alle mura della città.";
		dialogo [52] = "Un grosso castello si innalza \nal centro della capitale.";
		dialogo [53] = "Un mercante mi approccia.";
		dialogo [54] = "Controllo l'inventario e noto che posseggo trenta monete, anche chiamate cubloni da queste parti.";
		dialogo [55] = "Mentre mi avvicino al centro abiatato\n udisco dei rulli di tamburi e urla di gente.";
		dialogo [56] = "Si sta tenendo una parata in cui \nsfilano i cavalieri tornati da una battaglia \ncontro i giganti.";
		dialogo [57] = "La battaglia è stata distruttiva \ne i soldati sono a pezzi.";
		//città
		dialogo [58] = "A testa della parata c'è il comandante,\n una ragazza, molto intimidatoria.";
		dialogo [59] = "La folla acclama l'Ordine dei Cavalieri: \nGrandi! Siete la nostra salvezza!\n Athena sei un'eroina!\"\r\n";
		dialogo [60] = "Ah ecco, il comandante si chiama Athena.";
		dialogo [61] = "Cerco di raggiungerla,\n lei mi può aiutare essendo un pezzo grosso.";
		dialogo [62] = "Athena, Athena!";
		dialogo [63] = "Lei mi nota, ma decide di ignorarmi\n e proseguire per la strada principale,\n fino alla torre centrale.";
		dialogo [64] = "Schivo la gente e la inseguo fino all'entrata.";
		//dialogo con Athena
		dialogo [65] = "Athena posso parlare con te?\n Riguarda il mio viaggio, il perché sono qui.\n Per favore concedimi un minuto";
		dialogo [66] = "Le racconto tutta la mia storia,\n dal portale, al fulmine, ai giganti.";
		dialogo [67] = "Athena: Capisco. Benvenuto a Cubvlar,\n la terra dove il tempo è in mano ai Tre.";
		dialogo [68] = "Chi sono i Tre?";
		dialogo [69] = "Athena: Sono la coscienza del nostro mondo,\n praticamente i nostri dei.\n I loro nomi sono Boss (B), Alex (A) e Golo (G).";
		dialogo [70] = "Credo di aver sentito le loro voci parlare qualche volta.";
		dialogo [71] = "Athena: Amano commentare,\n non sono molto simpatici.";
		dialogo [72] = "Occhio a quello che dici -A";
		dialogo [73] = "Athena: Appunto.";
		dialogo [74] = "E i giganti? Cosa sono?";
		dialogo [75] = "Athena: Sono i nostri nemici,\n sono guidati dal loro re, Emmett il Gigacoso,\n e il loro scopo è conquistare questa terra.";
		dialogo [76] = "Quindi se vi aiuto a sconfiggerli potrò tornare a casa?";
		dialogo [77] = "Athena: Sempre che i Tre te lo permettano,\n ovviamente. Però prima devi allenarti, \ni giganti sono piuttosto impegnativi. Vieni con me.";
		dialogo [78] = "addestramento con Athena";
		//fine allenamento
		dialogo [79] = "Appena finito l'allenamento,\n la terra inizia a tremare.";
		dialogo [80] = "Molta gente urla.";
		dialogo [81] = "I giganti sono entrati in città.";
		dialogo [82] = "Athena: Su andiamo!";
		dialogo [83] = "Appena li raggiungiamo noto 5 giganti davanti a noi.";
		dialogo [84] = "Athena:Io mi occupo di quei 3,\n tu pensa ai restanti 2!";
		dialogo [85] = "Sissignora!";
		//combattimento  giganti
		dialogo[86] ="Combattimento";
		dialogo[87] = "CONTINUA SU TERMINALE :)";
		//dialogo[87] ="TUA VITA : " + p.getVita() + "\nVITA NEMICO: " + n.getVita()  ;
		//dopoCombattimento
		dialogo [88] = "Athena: Bravo, te la sei cavata,\n ma non è finita, guarda laggiù!";
		dialogo [89] = "La terra trema più forte di prima.";
		dialogo [90] = "La porta d'ingresso della città \nviene distrutta dall'entrata di un gigante\n alto circa 20 metri con una \ngrossa corona in testa.";
		dialogo [91] = "Athena: \nLui è Emmett il Gigacoso, il loro re.";
		dialogo [92] = "Quello lì ci schiaccia! Morirò!";
		dialogo [93] = "Sei il protagonista, non puoi morire... -B";
		dialogo [94] = "Athena: Ci penso io!";
		dialogo [95] = "Athena infligge 26 danni a Emmett\n e poi cade a terra per colpa\n di una ferita allo stomaco.";
		dialogo [96] = "Ora tocca a me!";
		//boss battle
		dialogo [97] = "Combattimento";
		dialogo [98] = "SEMPRE SU TERMINALE";
		
		//fine?
		dialogo [99] = "Ce l'ho fatta.";
		dialogo [100] = "L'ho sconfitto!";
		dialogo [101] = "Athena hai visto? C'è l'ho fatta!";
		dialogo [102] = "Athena: Complimenti ragazzo, ci hai salvato.";
		dialogo [103] = "La gente mi acclama,\n mi chiama eroe,\n mi lancia fiori e cibo.";
		dialogo [104] = "All'improvviso dal cielo cade un rubino\n rosso come il fuoco.";
		dialogo [105] = "Questo è un piccolo regalo da parte nostra -G";
		dialogo [106] = "Aprirà un portale magico -A";
		dialogo [107] = "Buon ritorno a casa -B";
		dialogo [108] = "E' ora di tornare, grazie a tutti.";
		dialogo [109] = "fine?!";
		dialogo [110] = "Il portale si richiude dietro di me.";
		dialogo [111] = "Sono a casa?";		
		dialogo [112] = "No, questo posto non è casa mia.";
		dialogo [113] = "Devo tornare a casa, dai miei fratelli.";
		dialogo [114] = "Devo tornare a casa, dai miei fratelli.";
		dialogo [115] = "Un fulmine squarcia il cielo che fino a pochi \nattimi prima era sereno.";
		dialogo [116] = "La luce si fa sempre più vicina a me.\r\n";
		dialogo [117] = "E dopo una scarica sul corpo, buio totale.";
		dialogo [118] = "*Il tempo è nelle mani dei Tre*.";
		dialogo [119] = "Ho fallito , non tornero mai più dai miei fratelli";
	}
	
	
	public void aggiornaVita(Protagonista p , Nemico n)  {
		this.p = p;
		this.n = n;
		
	}
	
	
	
	public void speak() {
		try {
			Thread.sleep(WT);//3500
			if(i< dialogo.length) {
				if(i == 5) {
					
				}
				
				if(i == 6) {
					tm.setMap(2);
				}
				else if(i == 7) {
					tm.setMap(1);

					//setPosition();
				}
				else if(i == 8) {
					scena.scene(this,1);		
				}
				if(i == 24) {
					tm.setMap(2);

				}
				if(i == 25) { 
					scena.scene(this, 2);
					tm.setMap(3);
				}
				if(i == 29) {
					tm.setMap(2);

				}
				if(i == 30) {
					direction = "up";
					scena.scene( this,3);
					tm.setMap(4);
				}
				
				if(i == 43) {
					tm.setMap(2);
					
				}
				
				if(i == 44) {
					direction = "down";
					scena.scene( this,4);
					tm.setMap(5);
				}
				if(i == 49) {
					direction = "up";
				}
				
				if(i == 50) {
					
					direction = "down";
					tm.setMap(2);
				}
				
				if(i == 51) {
					scena.scene(this, 5);
					tm.setMap(6);
				}
				if(i == 53) {
					tm.setMap(2);
				}
				
				if(i == 56) {
					scena.scene( this,6);
					tm.setMap(7);
				}
				if(i == 63) {
					tm.setMap(2);
					scena.scene(this, 7); 
					
				}
				if(i == 83) {
					tm.setMap(7);
					direction = "up";
					scena.scene(this, 8);
				}
				if(i == 84)  {
					tm.setMap(8);
				}
				if(i == 85) {
					//combattimento
					int vittoria = scena.scene(this, 9);
					tm.setMap(8);
					
					if(vittoria == 1) {
					   i = 89;
					}
					else if(vittoria == 2) {
					
					 i = 119;
					}
					
				
				}
				
				if(i == 95) {
					tm.setMap(2);
				}
	
				if(i == 95) {
					tm.setMap(7);
					scena.scene(this, 10);
					direction = "down";
					
				}
				
				if(i == 96) {
					tm.setMap(2);
				}
				
				if(i == 97) {
					tm.setMap(8);
					direction = "up";
					int vittoria = scena.scene(this, 11);
					if(vittoria == 1) {
						
					}
					else {
						i = 119;
					}
					
					
				}
				
				if(i == 99 ) {
					tm.setMap(7);
					direction = "down";
					scena.scene(this,10);
				}
				
				if(i == 119) {
					tm.setMap(0);
					Thread.sleep(3000);
					scena.scene(this,0);
					
				}
				
				gp.a.dialogoCorrente = dialogo[i];
				
				i++;
				
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	public void update() {
		//debug
		if(keyH.upPressed ==true) {
			direction = "up";
			y-=speed;

		}
		else if(keyH.downPressed) {
			direction = "down";
			y+= speed;
		}
		else if(keyH.leftPressed) {
			direction = "left";
			x-= speed;
		}
		else if(keyH.rightPressed) {
			direction = "right";
			x+= speed;
		}


	}

	public void draw(Graphics2D g2) {

		BufferedImage image = null;


		switch(direction) {
		case  "up":
			image = left ;
			break;

		case "down":
			image = right;
			break;

		case "left" :
			image = attackLeft;
			break;

		case "right" :

			image = attackRight;
			break;
		}
		g2.drawImage(image, x , y ,gp.tileSize , gp.tileSize,null);

		if(i<=119) {
				speak();
			}


	}
}




