package entity;

import java.awt.image.BufferedImage;

import TheSamsara.Personaggio;

public class Entity {
	
	public int x,y;
	public int speed;
	public BufferedImage left , right ,attackLeft , attackRight;
	public String direction;
	public String dialogo[] = new String [150];
	public String dialogoComb[] = new String [10];
	protected String nome;
	protected int vita;
	/*public Entity(String nome, int vita) {
		this.nome = nome;
		this.vita = vita;
		
		// TODO Auto-generated constructor stub
	}
	
	
*/
	
	public String getNome() {
		return nome;
	}




	public void setNome(String nome) {
		this.nome = nome;
	}




	public int getVita() {
		return vita;
	}




	public void setVita(int vita) {
		this.vita = vita;
	}




	public void speak() throws InterruptedException {}


}
