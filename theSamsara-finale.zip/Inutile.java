package theSamsara;

public class Inutile extends Item{

	public Inutile(String nome) {
		super(nome);
	}
	
	
}
