package TheSamsara;

import java.awt.Font;
import java.awt.Graphics2D;

public class UI {
	PannelloMappaGioco gp;
	Graphics2D g2;
	
	Font arial_40 , arial_80B;
	
	
	public void draw(Graphics2D g2) {
		
		
		
	}
	
}
