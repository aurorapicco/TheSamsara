package TheSamsara;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import entity.Player;





public class Dialoghi {
	PannelloMappaGioco gp;
	Graphics2D g2;
	Font arial_40, arial_80B;
	String ms = "";
	int i = 0;
	public String dialogoCorrente = "";
	
	
	public Dialoghi (PannelloMappaGioco gp) {
		this.gp = gp;
		
		arial_40 = new Font("Arial" , Font.PLAIN , 15);
		arial_80B = new Font("Arial" , Font.PLAIN , 80);
		
	}
	
	
	public void draw(Graphics2D g2) {
		this.g2 = g2;
		
		g2.setFont(arial_40);
		g2.setColor(Color.white);
		
		 drawDialogueScreen();
		 
	}
	
	public void drawDialogueScreen() {
		int x = gp.tileSize;
		int y = gp.tileSize/16;
		int larghezza = gp.worldWidth;
		int altezza = gp.worldHeight;
		drawSubWindow(x,y , larghezza ,altezza);
		
		g2.setFont(arial_40);
		g2.setColor(Color.white);
		
		for(String  line : dialogoCorrente.split("\n")  ) {
			g2.drawString(line, x, y*6);
			y+=4;
		}
		
		//i++;
			
	}
	
	public void drawSubWindow(int x , int y ,int larghezza , int altezza ) {
		
		g2.setColor(Color.black);
		g2.fillRoundRect(x, y, 400, 110, y,y );
	}
	
}
