package theSamsara;

public class Npc {
	protected String titolo;

	public Npc(String titolo) {
		this.titolo = titolo;
	}
	

	protected String getTitolo() {
		return titolo;
	}
	
	
	
}