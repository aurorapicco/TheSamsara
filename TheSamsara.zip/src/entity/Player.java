package entity;


import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import TheSamsara.InputTastiera;
import TheSamsara.PannelloMappaGioco;

public class Player extends Entity{
	PannelloMappaGioco gp;
	InputTastiera keyH;
	int i;

	public Player(PannelloMappaGioco gp, InputTastiera keyH) {
		this.gp = gp;
		this.keyH = keyH;

		setDefaultValues();
		getPlayerImage();
		setDialogo();
	}

	public void setDefaultValues() {
		x = 100;
		y = 100;
		speed = 4;
		direction = "down";
		i  = 0;
	}

	public void getPlayerImage() {

		try {
			left = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McFermoSx.png"));
			right = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McFermoDx.png"));
			attackLeft = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McCombattimentoSx.png"));
			attackRight = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McCombattimentoDx.png"));
			 
			/*left = ImageIO.read(getClass().getResourceAsStream("/player/boy_down1.png"));
			right = ImageIO.read(getClass().getResourceAsStream("/player/boy_up21.png"));
			attackLeft = ImageIO.read(getClass().getResourceAsStream("/player/boy_left1.png"));
			attackRight = ImageIO.read(getClass().getResourceAsStream("/player/boy_right1.png"));
		*/
		} catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void setDialogo() {
		//qua mettiamo tutti i dialoghi
		dialogo[0] = "Il portale si chiude dietro di me.";
		dialogo[1] = "Mc: Sono a casa?";
		dialogo[2] = "Mc: No ,questo posto non è casa mia";
		dialogo[3] = "Mc: Devo tornare a casa, dai miei fratelli.";
		dialogo[4] = "Un fulmine squarcia il cielo che fino a pochi attimi prima era sereno.";
		dialogo[5] = "La luce si fa sempre più vicina a me.\r\n";
		dialogo[6] = "E dopo una scarica sul corpo, buio totale.";
		//RISVEGLIO
		dialogo[7] = "Apro paino gli occhi";
		dialogo[8] = "???: Finalmente ti sei svegliato!";
		dialogo[9] = "Mc : Dove sono? Chi sei tu?";
		dialogo[10] = "???: Mi chiamo Ilde, sono una contadina, \n ti ho trovato a terra svenuto e ho deciso di portarti a casa mia.";
		dialogo[11] = "Mc: Ti ringrazio, Ilde.";
		dialogo[12] = "Ilde: Non sei di queste parti, vero? Qua tutti conoscono tutti, \ne la tua faccia non credo di averla mai vista nei miei centosessant'anni di vita.";
		dialogo[13] = "-B: Cavolo! Li porta bene :O";
		dialogo[14] = "Mc: No, mi sono ritrovato qui per errore. \nSapresti dirmi dove mi trovo?";
		dialogo[15] = "Ilde: Benvenuto nel Regno di Mirvlar, dove il tempo è duraturo.";
		dialogo[16] = "Mc: Cosa vuol dire?";
		dialogo[17] = "Mc: Ilde mi ignora, sembra che non abbia sentito.";
		dialogo[18] = "Ilde: Dovresti raggiungere la città, \nperò non è molto vicina e la strada è piena di pericoli.";
		dialogo[19] = "Ilde: Oh! Dovrebbe essere arrivato!";
		dialogo[20] = "Mc: Chi?!";
		dialogo[21] = "Sta per dire qualcosa di ironico, \nma si ferma in tempo.";
		dialogo[22] = "-A: Ci è mancato poco";
		dialogo[23] = "Ilde: Mio marito, l'emerito cavaliere Lord Swain. \nTi insegnerà qualche tecnica di combattimento.";
		//DOPO ESSERE USCITO DALLA CASA
		dialogo[24] = "";
		
		
		
	}
	
	
	public void speak() {
		try {
			Thread.sleep(3500);
			if(i< dialogo.length) {
				gp.a.dialogoCorrente = dialogo[i];
				i++;
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}


	public void update() {
		//debug
		if(keyH.upPressed ==true) {
			direction = "up";
			y-=speed;

		}
		else if(keyH.downPressed) {
			direction = "down";
			y+= speed;
		}
		else if(keyH.leftPressed) {
			direction = "left";
			x-= speed;
		}
		else if(keyH.rightPressed) {
			direction = "right";
			x+= speed;
		}
		
		
	}

	public void draw(Graphics2D g2) {

		BufferedImage image = null;


		switch(direction) {
		case  "up":
			image = left ;
			break;

		case "down":
			image = right;
			break;

		case "left" :
			image = attackLeft;
			break;

		case "right" :

			image = attackRight;
			break;
		}
		g2.drawImage(image, x , y ,gp.tileSize , gp.tileSize,null);
		
		if(i<=24) {
		
			speak();
		}
		
		
	}


}
