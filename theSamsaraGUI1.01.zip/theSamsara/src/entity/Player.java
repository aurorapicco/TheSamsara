package entity;


import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import TheSamsara.InputTastiera;
import TheSamsara.PannelloMappaGioco;
import TheSamsara.Scena;
import tile.TileManager;

public class Player extends Entity{
	PannelloMappaGioco gp;
	InputTastiera keyH;
	TileManager tm;
	Scena scena;
	int pos = 0;
	int i;

	public Player(PannelloMappaGioco gp, InputTastiera keyH,TileManager tm ,Scena scena) {
		this.gp = gp;
		this.keyH = keyH;
		this.tm = tm;
		this.scena = scena;

		setDefaultValues();
		getPlayerImage();
		setDialogo();
	}

	public void setDefaultValues() {
		x = 100;
		y = 100;
		speed = 4;
		direction = "down";
		i  = 0;
		scena.scene(this,0);
	}

	public void setPosition(int x , int y) {
		this.x = x;
		this.y = y;
	}

	public void getPlayerImage() {

		try {
			left = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McFermoSx.png"));
			right = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McFermoDx.png"));
			attackLeft = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McCombattimentoSx.png"));
			attackRight = ImageIO.read(getClass().getResourceAsStream("/Personaggio/McCombattimentoDx.png"));

			/*left = ImageIO.read(getClass().getResourceAsStream("/player/boy_down1.png"));
			right = ImageIO.read(getClass().getResourceAsStream("/player/boy_up21.png"));
			attackLeft = ImageIO.read(getClass().getResourceAsStream("/player/boy_left1.png"));
			attackRight = ImageIO.read(getClass().getResourceAsStream("/player/boy_right1.png"));
			 */
		} catch(IOException e) {
			e.printStackTrace();
		}

	}

	public void setDialogo() {
		//qua mettiamo tutti i dialoghi
		dialogo[0] = "Il portale si chiude dietro di me.";
		dialogo[1] = "Mc: Sono a casa?";
		dialogo[2] = "Mc: No ,questo posto non è casa mia";
		dialogo[3] = "Mc: Devo tornare a casa, dai miei fratelli.";
		dialogo[4] = "Un fulmine squarcia il cielo che fino a pochi attimi prima era sereno.";
		dialogo[5] = "La luce si fa sempre più vicina a me.\r\n";
		dialogo[6] = "E dopo una scarica sul corpo, buio totale.";
		//RISVEGLIO
		dialogo[7] = "Apro piano gli occhi";
		dialogo[8] = "???: Finalmente ti sei svegliato!";
		dialogo[9] = "Mc : Dove sono? Chi sei tu?";
		dialogo[10] = "???: Mi chiamo Ilde, sono una contadina, \n ti ho trovato a terra svenuto e ho deciso di portarti a casa mia.";
		dialogo[11] = "Mc: Ti ringrazio, Ilde.";
		dialogo[12] = "Ilde: Non sei di queste parti, vero? Qua tutti conoscono tutti, \ne la tua faccia \nnon credo di averla mai vista nei miei centosessant'anni di vita.";
		dialogo[13] = "-B: Cavolo! Li porta bene :O";
		dialogo[14] = "Mc: No, mi sono ritrovato qui per errore. \nSapresti dirmi dove mi trovo?";
		dialogo[15] = "Ilde: Benvenuto nel Regno di Mirvlar, dove il tempo è duraturo.";
		dialogo[16] = "Mc: Cosa vuol dire?";
		dialogo[17] = "Mc: Ilde mi ignora, sembra che non abbia sentito.";
		dialogo[18] = "Ilde: Dovresti raggiungere la città, \nperò non è molto vicina e la strada è piena di pericoli.";
		dialogo[19] = "Ilde: Oh! Dovrebbe essere arrivato!";
		dialogo[20] = "Mc: Chi?!";
		dialogo[21] = "Sta per dire qualcosa di ironico, \nma si ferma in tempo.";
		dialogo[22] = "-A: Ci è mancato poco";
		dialogo[23] = "* Un secondo per respirare* \n:) oppure di più";
		dialogo[24] = "Ilde: Mio marito, l'emerito cavaliere Lord Swain. \nTi insegnerà qualche tecnica di combattimento.";
		//ESCO DALLA CASA
		dialogo[25] = "Esco dalla casa e incontro un vecchietto.";
		dialogo[26] = "Buongiorno, lei è Lord Swain?";
		dialogo[27] = "Swain: Sono io, vieni caro, \nti insegnerò un trucchetto per sopravvivvere qui.";
		dialogo[28] = "Swain: Ora sei pronto. Segui il sentiero,\n ti porterà in città, \nbuon viaggio. Che i Tre ti proteggano!";
		//villaggio
		dialogo[29] = "Proseguo verso la strada principale.";
		dialogo[30] = "Arrivo a un villaggio molto rustico.";
		dialogo[31] = "Un prete mi sta fissando, che inquietante.";
		dialogo[32] =" ???: Salve straniero, dove sei diretto?";
		dialogo[33] = "Alla città.";
		dialogo[34] = "Padre Viscur: Io sono Padre Viscur,\n lieto di conoscerti.";
		dialogo[35] = "Piacere mio, la città è da quella parte?";
		dialogo[36] = "Padre Viscur: Esattamente.";
		dialogo[37] = "Allora ti ringrazio, arrivederci.";
		dialogo[38] = "Padre Viscur: Aspetta!\n La strada è molto pericolosa,\n voglio farti un regalo.";
		dialogo[39] = "Mi porge 5 pozioni curative.";
		dialogo[40] = "Padre Viscur: Queste le produco personalmente.\n Ti cureranno di 10 punti vita.";
		dialogo[41] = "Allora grazie e arrivederci";
		dialogo[42] = "Non ti hanno insegnato che non\n si accettano regali dagli sconosciuti? -G";
		dialogo[43] = "Padre Viscur: Buon viaggio, a presto.";





	}

	public void speak() {
		try {
			Thread.sleep(100);//3500
			if(i< dialogo.length) {

				if(i == 6) {
					tm.setMap(2);
				}
				else if(i == 7) {
					tm.setMap(1);

					//setPosition();
				}
				else if(i == 8) {
					scena.scene(this,1);		
				}
				if(i == 24) {
					tm.setMap(2);

				}
				if(i == 25) { 
					scena.scene(this, 2);
					tm.setMap(3);
				}
				if(i == 29) {
					tm.setMap(2);

				}

				if(i == 30) {
					scena.scene(this, 3);
					tm.setMap(4);
				}



				gp.a.dialogoCorrente = dialogo[i];
				i++;
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	public void update() {
		//debug
		if(keyH.upPressed ==true) {
			direction = "up";
			y-=speed;

		}
		else if(keyH.downPressed) {
			direction = "down";
			y+= speed;
		}
		else if(keyH.leftPressed) {
			direction = "left";
			x-= speed;
		}
		else if(keyH.rightPressed) {
			direction = "right";
			x+= speed;
		}


	}

	public void draw(Graphics2D g2) {

		BufferedImage image = null;


		switch(direction) {
		case  "up":
			image = left ;
			break;

		case "down":
			image = right;
			break;

		case "left" :
			image = attackLeft;
			break;

		case "right" :

			image = attackRight;
			break;
		}
		g2.drawImage(image, x , y ,gp.tileSize , gp.tileSize,null);

		if(i<=43) {

			speak();
		}


	}


}
