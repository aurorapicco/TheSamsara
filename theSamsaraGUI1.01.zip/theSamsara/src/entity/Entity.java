package entity;

import java.awt.image.BufferedImage;

public class Entity {
	public int x,y;
	public int speed;
	public BufferedImage left , right ,attackLeft , attackRight;
	public String direction;
	public String dialogo[] = new String [100];
	
	public void speak() throws InterruptedException {}


}
