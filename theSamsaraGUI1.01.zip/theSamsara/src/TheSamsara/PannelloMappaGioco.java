package TheSamsara;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import entity.Athena;
import entity.Cavaliere;
import entity.LordSwain;
import entity.PadreViscur;
import entity.Player;
import entity.npc_Ilde;
import tile.TileManager;

public class PannelloMappaGioco  extends JPanel implements Runnable{

	private static final long serialVersionUID = 1L;
	final int TileSizeOG = 16;//16x16pixel
	final int scale  = 4; // moltiplica la grandezza per 3

	public final int tileSize = TileSizeOG * scale;//48x48
	public final int grandezzaMassimaSchermoCol = 16;//16 original
	public final int grandezzaMassimaSchermoRighe = 12;//12 original
	public final int altezzaSchermo = tileSize * grandezzaMassimaSchermoCol; //768 pixel
	public final int lunghezzaSchermo = tileSize * grandezzaMassimaSchermoRighe; // 576 pixel

	//maxFPS
	int FPS  = 30;
	InputTastiera keyH = new InputTastiera();
	Thread startGameThread;
	public Dialoghi a = new Dialoghi(this);
	TileManager tileM = new TileManager(this);

	public Cavaliere cavaliere = new Cavaliere(this,keyH);
	public npc_Ilde npc_i = new npc_Ilde(this,keyH);
	public Athena athena = new Athena(this,keyH);
	public LordSwain swain = new LordSwain(this,keyH);
	public PadreViscur pv = new PadreViscur(this, keyH);
	
	//scena
	public Scena scena = new Scena(this,tileM, cavaliere, athena, npc_i,swain,pv);
	//player
	public Player player = new Player(this,keyH , tileM ,scena);





	//public Npc2 npc2 = new Npc2(this);



	int x = 100;
	int y = 100;
	int speed = 4;

	//mappa Gioco 
	public final int maxWorldCol = 50;
	public final int maxWorldRow = 50;
	public final int maxMap = 10;
	public int currentMap = 0;
	public final int worldWidth = tileSize * grandezzaMassimaSchermoCol;
	public final int worldHeight = tileSize * grandezzaMassimaSchermoRighe;
	public final int statoDialogo = 1;
	public int map;

	public PannelloMappaGioco() {

		this.setPreferredSize(new Dimension(altezzaSchermo,lunghezzaSchermo)); //grandezza JPanel
		this.setBackground(Color.black);
		this.setDoubleBuffered(true);
		this.addKeyListener(keyH);
		this.setFocusable(true);
	}

	public void startGameThread () {

		startGameThread = new Thread(this);
		startGameThread.start();

	}

	@Override
	public void run() {
		double drawInterval = 1000000000/FPS;
		double nextDrawTime = System.nanoTime() + drawInterval;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		int timer = 0;
		int drawCount = 0;


		while(startGameThread != null) {// fino a quando thread  esiste allora rimane dentro il while

			// 1 UPDATE : aggiorna la  posizione 
			currentTime = System.nanoTime();

			delta+= (currentTime - lastTime ) / drawInterval;
			timer += (currentTime -lastTime);
			lastTime = currentTime;

			if(delta>= 1) {
				update();
				repaint();
				delta--;
				drawCount++;
			}

			if(timer >= 1000000000) {
				System.out.println("FPS:" + drawCount);
				drawCount = 0;
				timer = 0;
			}

			;		}

	}

	public void update() {


		//npc2.update();
		npc_i.update();
		player.update();
		athena.update();
		cavaliere.update();
		swain.update();
		pv.update();
	}

	public void paintComponent(Graphics g) {

		super.paintComponent(g);

		Graphics2D g2  = (Graphics2D) g;// Graphics2D estende la classe Graphics per facitilare il controllo della geometria del gioco  , cooredinate...

		tileM.draw(g2);
		player.draw(g2);
		npc_i.draw(g2);
		athena.draw(g2);
		cavaliere.draw(g2);
		swain.draw(g2);
		pv.draw(g2);
		a.draw(g2); 

		g2.dispose();

	}





}
