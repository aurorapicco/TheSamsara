package TheSamsara;

import javax.swing.JFrame;

public class MainTemporaneo {
	public static void main(String [] args) {
		
		JFrame window = new JFrame ();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setTitle("The Samsara");
		
		PannelloMappaGioco gamePanel = new PannelloMappaGioco ();
		window.add(gamePanel);
		
		window.pack();//La finestra del gioco sarà grande quanto le impostazioni messe in PannelloMappaGioco
		
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		gamePanel.startGameThread();
	}

}
