package TheSamsara;

import entity.Athena;
import entity.Cavaliere;
import entity.Entity;
import entity.LordSwain;
import entity.PadreViscur;
import entity.Player;
import entity.npc_Ilde;
import tile.TileManager;


public class Scena {
	PannelloMappaGioco gp;
	 Cavaliere cavaliere;
	 npc_Ilde Ilde;
	 Athena athena;
	 LordSwain sw;
	TileManager tm;
	PadreViscur pv ;
	private int i ;
	public Scena(PannelloMappaGioco gp ,TileManager tm , Cavaliere cavaliere , Athena athena , npc_Ilde Ilde ,LordSwain sw ,PadreViscur pv) {
		this.gp = gp;
		this.cavaliere = cavaliere;
		this.athena = athena;
		this.Ilde = Ilde;
		this.sw = sw;
		this.tm = tm;
		this.pv = pv;
		this.i = 0;
		
	}
	//qua andranno le scene
	
	public void scene(Player mc,int i) {

		switch(i) {
		
		case 0: 
			mc.setPosition(100, 100);
			break;
		case 1: 
			//Ilde.setPosition(150, 100);
			Ilde.setPosition(150, 100);
			break;
		case 2: 
			Ilde.setPosition(789, 789);
			sw.setPosition(150, 100);
			break;
		case 3: 
			sw.setPosition(789, 789);
			pv.setPosition(150,100);
			break;

		}
	}


}
